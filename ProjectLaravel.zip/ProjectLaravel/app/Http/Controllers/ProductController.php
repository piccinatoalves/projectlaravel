<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Category;
use App\Models\ProductImages;
use DB;
use Validator;

class ProductController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $products = Product::get();
        $categories = Category::get();
        $selected_cat = [];

        return view('product.index', compact('products', 'categories', 'selected_cat'));
    }

    public function add()
    {
        $categories = Category::get();
        return view('product.add', compact('categories'));
    }

    public function save(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|min:10|max:255',
            'description' => 'required'
        ]);

        if (!$validator->fails()) {
            $images = $request->file('images');

            $product = Product::create([
                'name' => $request->input('name'),
                'description' => $request->input('description')
            ]);

            if (!empty($product) && !empty($images)) {
                foreach ($images as $key => $row) {
                    if (!empty($row)) {
                        $fileName = time() . $key . '.' . $row->getClientOriginalExtencions();
                        $row->move($this->path, $fileName);
                        $image = new ProductImages;
                        $image->product_id = $product->id;
                        $image->image = $fileName;
                        $image->save();
                    }
                }
            }
            $product->categories()->sync($request->input('category'));
        }
        return redirect()->route('product.index');
    }

    public function edit($id)
    {
        $product = Product::find($id);

        if (!empty($product)) {
            $categories = Category::get();
            $images = ProductImages::where('product_id', $product->id)->get();
            $selected_cat = array();

            foreach ($product->$categories as $category) {
                $selected_cat[] = $category->pivot->category_id;
            }
            return view('product_edit', compact('product', 'categories', 'selected_cat', 'images'));
        }
        redirect()->route('product.index');
    }

    public function update(Request $request, $id)
    {
        $images = $request->file('images');
        $category = $request->input('category');

        $product = Product::find($id);

        if (!empty($product)) {
            if (!empty($images)) {
                foreach ($images as $key => $row) {
                    if (!empty($row)) {
                        $fileName = time() . $key . '.' . $row->getClientOriginalExtencions();
                        $row->move($this->path, $fileName);
                        $image = new ProductImages;
                        $image->product_id = $product->id;
                        $image->image = $fileName;
                        $image->save();
                    }
                }
            }
            if (!empty($category)) {
                $product->categories()->sync($category);
            }
            $product->update([
                'name' => $request->input('name'),
                'description' => $request->input('description')

            ]);
        }
        return redirect()->route('product.index');
    }
}
